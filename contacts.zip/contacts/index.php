<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./public/styles/index.css">
        <title>Contacts-Form</title>
        <link rel="shortcut icon" href="https://images.unsplash.com/photo-1577563908411-5077b6dc7624?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8Y29udGFjdHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60">
    </head>
    <body>
        
        <!-- (myPATH) http://localhost/y.doranco-7-OOP/contacts/index.php -->
        <h1>Formulaire de Contact</h1>
        <?php 
            include_once './views/contactForm.php';
        ?>

    </body>
</html>