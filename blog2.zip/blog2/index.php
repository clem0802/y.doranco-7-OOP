<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="fr">

<?php 
    $title = "BLOG-Accueil";
    include_once './components/head.php';
?>




<body>
    <!-- (myPATH) http://localhost/y.doranco-7-OOP/blog2/index.php -->
    <?php 
        include_once './components/navbar.php';
    ?>


    <h1>Accueil: Page des posts</h1>
    <p>(A faire: dans signup, vérifier si l'utilisateur n'est pas déjà inscrit)</p>
    <p>(A faire: dans profil créer le formulaire pour ajouter des posts)</p>
    <p>(A faire: dans profil afficher les posts de l'utilisateur)</p>
    <p>(A faire: afficher tous les posts)</p>



    <?php 
        // echo "<h3><a href='profil.php'>Aller voir les profils</a></h3>";
        // echo "<h3><a href='auth.php'>Aller au formulaire d'inscription</a></h3>";
    ?>
</body>

</html>





