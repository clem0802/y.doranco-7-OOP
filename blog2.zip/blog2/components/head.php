<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="./public/styles/style.css">

        <title>
            <?=$title?>
        </title>
        <link rel="shortcut icon" href="https://images.unsplash.com/photo-1639834382170-e640d6554324?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTMyfHxwdXJwbGUlMjBjb2xvcnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60">
</head>